# Changelog

## 1.2.1

- `graphql` was incorrectly listed as a dev dependency.

## 1.2.0

- Fixed CLI.

## 1.1.0

- Added `childNodes` field
- Added TypeScript declaration file

## 1.0.0

Initial release